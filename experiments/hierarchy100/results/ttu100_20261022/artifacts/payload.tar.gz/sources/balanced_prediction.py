"""Taxon-balanced distance scoring from unfiltered SPrOUT exon matrices.

No mixture labels are read. Scores are relative evidence, not calibrated probabilities.
"""
from collections import defaultdict
from pathlib import Path
import re

import numpy as np
import pandas as pd


def gene_from_matrix(path):
    """SPrOUT names matrices GENE.EXON.cleaned.csv; leave other names intact."""
    return re.sub(r"\.\d+$", "", Path(path).name.removesuffix(".cleaned.csv"))


def balanced_summary(matrix_dir, project, level):
    index = {"o": 0, "f": 1, "g": 2, "s": 3}[level]
    gene_scores = defaultdict(list)
    opportunities = defaultdict(set)
    exon_counts = defaultdict(int)
    detail = []
    paths = sorted(Path(matrix_dir).glob("*.cleaned.csv"))
    if not paths:
        raise ValueError("No raw cleaned matrices found")
    for path in paths:
        gene = gene_from_matrix(path)
        df = pd.read_csv(path, index_col=0)
        queries = [c for c in df.columns if project in c]
        refs = df.loc[[isinstance(n, str) and project not in n and "NODE" not in n
                       for n in df.index], queries].copy()
        if not queries or refs.empty:
            continue
        parts = [n.strip("'").removeprefix("_R_").split("_") for n in refs.index]
        if any(len(p) < 4 for p in parts):
            raise ValueError(f"Malformed reference taxonomy in {path}")
        if not np.isfinite(refs.to_numpy()).all() or (refs.to_numpy() < 0).any() or (refs.to_numpy() >= 999).any():
            raise ValueError(f"Expected finite unfiltered patristic distances in {path}")
        # Replicate recoveries cannot multiply a species' contribution. Each
        # species, then genus, then target taxon receives equal weight.
        refs.index = pd.MultiIndex.from_tuples([tuple(p[:4]) for p in parts])
        distances = refs.groupby(level=list(range(4))).mean()
        if index < 3:
            distances = distances.groupby(level=[0, 1, 2]).mean()
        if index < 2:
            distances = distances.groupby(level=list(range(index + 1))).mean()
        background = distances.median(axis=0)
        # Zero background means no discriminating positive contrast.
        contrast = ((background - distances) / background.replace(0, np.nan)).clip(0, 1).fillna(0)
        exon_counts[gene] += 1
        for lineage, values in contrast.iterrows():
            lineage = lineage if isinstance(lineage, tuple) else (lineage,)
            taxon = "_".join(lineage[2:4]) if level == "s" else lineage[index]
            # Multiple assembled contigs cannot multiply a taxon's exon score.
            value = float(values.max())
            gene_scores[taxon, gene].append(value)
            opportunities[taxon].add(gene)
            detail.append({"matrix": path.name, "gene": gene, "taxon": taxon,
                           "exon_score": value, "query_columns": len(queries)})
    if not exon_counts:
        raise ValueError(f"No reference/query evidence for project {project!r}")
    totals = defaultdict(float)
    for (taxon, gene), values in gene_scores.items():
        # Missing reference exons contribute zero; every gene has budget <= 1.
        totals[taxon] += sum(values) / exon_counts[gene]
    summary = pd.DataFrame([{"row_name": taxon, "sum_of_total_value": value,
                             "available_genes": len(opportunities[taxon]),
                             "scoring_method": "taxon-balanced"}
                            for taxon, value in totals.items()])
    values = summary.sum_of_total_value
    sd = values.std(ddof=0)
    summary["z_score"] = (values - values.mean()) / sd if sd > 0 else 0.0
    return summary.sort_values(["sum_of_total_value", "row_name"], ascending=[False, True]), pd.DataFrame(detail)

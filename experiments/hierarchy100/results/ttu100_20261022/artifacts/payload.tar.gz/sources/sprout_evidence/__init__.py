"""Experimental statistics on fixed SPrOUT tree-distance evidence."""
__version__ = "0.1.0"

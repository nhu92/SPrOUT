"""Standalone inspect/filter/export panel. No ground truth is embedded."""
import csv
import json
import math
from pathlib import Path


def write_panel(result,output):
    output=Path(output);output.mkdir(parents=True,exist_ok=True)
    (output/'evidence.json').write_text(json.dumps(result,indent=2,allow_nan=False),encoding='utf-8')
    rows=result['rows']
    with (output/'evidence.csv').open('w',encoding='utf-8-sig',newline='') as h:
        writer=csv.DictWriter(h,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    (output/'candidates.txt').write_text(''.join(r['family']+'\n' for r in rows if r['selected']),encoding='utf-8')
    (output/'unconfirmed.txt').write_text(''.join(r['family']+'\n' for r in rows if r['unconfirmed']),encoding='utf-8')
    data=json.dumps(result,allow_nan=False).replace('<','\\u003c')
    html=TEMPLATE.replace('__DATA__',data)
    (output/'panel.html').write_text(html,encoding='utf-8')


def apply_policy(result,policy):
    """Replay exactly the panel's filter/override semantics in a batch workflow."""
    if policy.get('schema')!=1 or policy.get('project')!=result['project']:raise ValueError('Policy schema/project mismatch')
    if policy.get('experimental_settings')!=result['settings']:raise ValueError('Policy belongs to different analysis settings')
    p=policy['filters'];overrides=policy.get('overrides',{})
    known={r['family'] for r in result['rows']}
    if not set(overrides)<=known or any(type(x) is not bool for x in overrides.values()):raise ValueError('Unknown family or non-boolean override')
    if p['route'] not in ['all','a','b','c','pending']:raise ValueError('Unknown base list')
    numeric={k:float(p[k]) for k in ['freq','genes','coverage','lower','share']}
    if not all(math.isfinite(x) for x in numeric.values()):raise ValueError('Finite filter values required')
    if any(not 0<=numeric[k]<=1 for k in ['freq','lower','share']) or min(numeric['genes'],numeric['coverage'])<0:raise ValueError('Invalid filter range')
    z=None if p['z']=='' else float(p['z'])
    acs=None if p.get('acs','')=='' else float(p['acs'])
    if z is not None and not math.isfinite(z):raise ValueError('Finite Z filter required')
    if acs is not None and (not math.isfinite(acs) or acs<0):raise ValueError('Nonnegative finite ACS filter required')
    selected=[]
    for r in result['rows']:
        route=p['route']
        accepted=(route=='all' or route=='a' and r['native_selected'] or route=='b' and r['hybrid_selected'] or
            route=='c' and r['selected'] or route=='pending' and r['unconfirmed'])
        accepted=accepted and p['search'].lower() in r['family'].lower() and (z is None or r['z']>=z)
        accepted=accepted and (acs is None or r['acs']>=acs)
        accepted=accepted and r['selection_frequency']>=numeric['freq'] and r['discriminating_genes']>=numeric['genes']
        accepted=accepted and r['comparable_genes']>=numeric['coverage'] and r['bootstrap_lower']>=numeric['lower']
        accepted=accepted and r['max_gene_share']<=numeric['share']
        if overrides.get(r['family'],accepted):selected.append(r['family'])
    return selected


TEMPLATE='''<!doctype html><html lang="zh"><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>SPrOUT · Evidence</title>
<style>body{font:15px system-ui;margin:32px;background:#f6f7f5;color:#20332e}main{max-width:1400px;margin:auto}h1{font-size:30px}p{max-width:1000px;line-height:1.6}.controls{display:flex;gap:18px;flex-wrap:wrap;padding:20px;background:white;border-radius:12px}label{display:grid;gap:6px}input,select,button{padding:8px;border:1px solid #bfcfc8;border-radius:6px}button{cursor:pointer;background:#e3eee8}table{border-collapse:collapse;width:100%;background:white;margin-top:20px}th,td{padding:10px;border-bottom:1px solid #dae2de;text-align:left;white-space:nowrap}th{position:sticky;top:0;background:#e8efeb;cursor:pointer}.scroll{overflow:auto;max-height:65vh}.note{color:#56695f;font-size:13px}.ok{color:#17634a}.pending{color:#986123}#status{margin:16px 0}</style>
<main><h1>SPrOUT · 统一证据面板</h1><p id="project"></p>
<p>所有参考panel中的科均保留。选择稳定度衡量gene重采样下的重复入选，不是存在概率。P值尚未校准。筛选只影响导出名单，不重建树或加入参考。</p>
<div class="controls"><label>基础名单<select id="route"><option value="all">全部科</option><option value="c" selected>确认方案C</option><option value="b">Z＋gene挽救 B</option><option value="a">原始Z</option><option value="pending">待确认</option></select></label>
<label>搜索科名<input id="search" placeholder="Family"></label>
<label>最低Z（可空）<input id="z" type="number" step="0.1"></label>
<label>最低ACS（可空）<input id="acs" type="number" min="0" step="1"></label>
<label>最低选择稳定度<input id="freq" type="number" min="0" max="1" step="0.05" value="0"></label>
<label>最少区分gene<input id="genes" type="number" min="0" value="0"></label>
<label>最少可比较gene<input id="coverage" type="number" min="0" value="0"></label>
<label>最低距离稳定下界<input id="lower" type="number" min="0" max="1" step="0.01" value="0"></label>
<label>最大单gene贡献占比<input id="share" type="number" min="0" max="1" step="0.05" value="1"></label>
<button id="export">导出选择名单</button><button id="policy">导出筛选条件</button><button id="reset">重置</button></div>
<p id="status"></p><p class="note">默认按选择稳定度排序。点列名排序；复选框可手动覆盖当前筛选。浅色显示状态不会隐藏完整证据。手动筛选后的结果未自动获得准确率、NPV或FDR保证。</p>
<div class="scroll"><table><thead><tr id="head"></tr></thead><tbody id="body"></tbody></table></div>
<p class="note" id="scope"></p></main><script>
const d=__DATA__;
const el=id=>document.getElementById(id);const controls=['route','search','z','acs','freq','genes','coverage','lower','share'];
const overrides=new Map();let sort='selection_frequency',asc=false;
const cols=[['family','科'],['admission_route','证据通道'],['acs','ACS'],['z','Z'],['discriminating_genes','区分gene'],['comparable_genes','可比较gene'],['reference_species','参考species'],['bootstrap_lower','距离下界'],['selection_frequency','选择稳定度'],['selection_frequency_mc_interval','稳定度MC区间'],['max_gene_share','最大gene占比'],['acs_interval','ACS gene区间'],['z_interval','Z gene区间'],['margin_interval','距离均值gene区间'],['max_delete_one_mean_shift','删除单gene影响'],['missing_sibling_genes','缺少同目竞争gene'],['presence_p','存在P值'],['reason','当前状态']];
el('project').textContent=d.project+' · '+d.genes+' recovered genes · '+d.rows.length+' reference families';el('scope').textContent=d.stability_scope+' | '+d.interval_scope;
function policy(){return Object.fromEntries(controls.map(k=>[k,el(k).value]))}
function accepts(r){const p=policy();return (p.route==='all'||p.route==='c'&&r.selected||p.route==='b'&&r.hybrid_selected||p.route==='a'&&r.native_selected||p.route==='pending'&&r.unconfirmed)&&r.family.toLowerCase().includes(p.search.toLowerCase())&&(p.z===''||r.z>=Number(p.z))&&(p.acs===''||r.acs>=Number(p.acs))&&r.selection_frequency>=Number(p.freq)&&r.discriminating_genes>=Number(p.genes)&&r.comparable_genes>=Number(p.coverage)&&r.bootstrap_lower>=Number(p.lower)&&r.max_gene_share<=Number(p.share)}
function chosen(r){return overrides.has(r.family)?overrides.get(r.family):accepts(r)}
function render(){const rows=[...d.rows].sort((a,b)=>{const x=a[sort],y=b[sort];return (typeof x==='number'?x-y:String(x).localeCompare(String(y)))*(asc?1:-1)});el('body').replaceChildren();for(const r of rows){const tr=document.createElement('tr');const td=document.createElement('td'),check=document.createElement('input');check.type='checkbox';check.checked=chosen(r);check.onchange=()=>{overrides.set(r.family,check.checked);status()};td.append(check);tr.append(td);for(const [key] of cols){const c=document.createElement('td');const v=r[key];c.textContent=v==null?'未校准':Array.isArray(v)?v.map(x=>x.toFixed(3)).join('–'):typeof v==='number'?Number.isInteger(v)?v:v.toFixed(4):v;tr.append(c)}el('body').append(tr)}status()}
function status(){el('status').textContent=d.rows.filter(chosen).length+' / '+d.rows.length+' 科将被导出 · 手动覆盖 '+overrides.size+' 项'}
function download(name,text,type){const url=URL.createObjectURL(new Blob([text],{type}));const a=document.createElement('a');a.href=url;a.download=name;a.click();URL.revokeObjectURL(url)}
const h=document.createElement('th');h.textContent='选择';el('head').append(h);for(const [key,label] of cols){const th=document.createElement('th');th.textContent=label;th.onclick=()=>{asc=sort===key?!asc:false;sort=key;render()};el('head').append(th)}
for(const k of controls)el(k).oninput=render;
el('export').onclick=()=>download(d.project+'.selected.txt',d.rows.filter(chosen).map(r=>r.family).join('\\n')+'\\n','text/plain');
el('policy').onclick=()=>download(d.project+'.filter.json',JSON.stringify({schema:1,project:d.project,experimental_settings:d.settings,filters:policy(),overrides:Object.fromEntries(overrides),selected:d.rows.filter(chosen).map(r=>r.family),presence_p_calibrated:false},null,2),'application/json');
el('reset').onclick=()=>{overrides.clear();for(const k of controls)el(k).value={route:'c',search:'',z:'',acs:'',freq:0,genes:0,coverage:0,lower:0,share:1}[k];render()};render();
</script></html>'''

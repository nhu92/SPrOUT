"""Unmodified scoring snapshot used by the completed 100-sample experiment."""

"""Read tree-distance products without editing trees, references or labels."""
from __future__ import annotations
import csv
import gzip
import hashlib
import importlib.util
import json
import re
import tempfile
from pathlib import Path
import numpy as np
import pandas as pd
from .frozen.adaptive import extract_family_features


def save_json(path, value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    opener=gzip.open if path.suffix=='.gz' else open
    with tempfile.NamedTemporaryFile(dir=path.parent,prefix=path.name+'.',suffix='.tmp',delete=False) as h:temporary=Path(h.name)
    try:
        with opener(temporary,'wt',encoding='utf-8') as h:json.dump(value,h,allow_nan=False)
        temporary.replace(path)
    finally:temporary.unlink(missing_ok=True)


def read_json(path):
    path=Path(path);opener=gzip.open if path.suffix=='.gz' else open
    with opener(path,'rt',encoding='utf-8') as h:return json.load(h)


def acs_gene_table(matrix_dir, project, genes, families):
    # Reuse precisely the original masking/digit-normalization semantics.
    source=Path(__file__).resolve().parents[1]/'03_distance_matrices.py'
    spec=importlib.util.spec_from_file_location('_sprout_original_distance',source)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    result=np.zeros((len(genes),len(families)))
    gi={g:i for i,g in enumerate(genes)};fi={f:i for i,f in enumerate(families)}
    references={f:set() for f in families};query_counts=[]
    for path in sorted(Path(matrix_dir).glob('*.cleaned.csv')):
        gene=re.sub(r'\.\d+$','',path.name.removesuffix('.cleaned.csv'))
        frame=pd.read_csv(path)
        query_counts.append(sum(project in c for c in frame.columns[1:]))
        for label in frame.iloc[:,0]:
            label=str(label)
            if project not in label and 'NODE' not in label:
                parts=label.strip("'").removeprefix('_R_').split('_')
                if len(parts)>1 and parts[1] in references:references[parts[1]].add(label)
        mask=path.with_name(path.name.removesuffix('cleaned.csv')+'list.txt')
        clean=module.clean_up_matrix(frame,project,1.96,mask if mask.exists() else None,False,False)
        clean=clean[~clean.iloc[:,0].str.contains('NODE')]
        for row in clean.itertuples(index=False,name=None):
            family=str(row[0]).split('_')[1]
            if family not in fi:raise ValueError('ACS taxonomy absent from raw feature panel: '+family)
            result[gi[gene],fi[family]]+=sum(1/(1+float(x)) for x in row[1:])
    return result,{f:len(names) for f,names in references.items()},query_counts


def extract(matrix_dir, predictions, project):
    matrix_dir=Path(matrix_dir);predictions=Path(predictions)
    files=sorted(matrix_dir.glob('*.cleaned.csv'))+sorted(matrix_dir.glob('*.list.txt'))+[predictions]
    before={str(p.resolve()):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
    raw=extract_family_features(matrix_dir,project)
    with predictions.open(encoding='utf-8-sig',newline='') as h:
        native={r['row_name']:dict(score=float(r['sum_of_total_value']),z=float(r['z_score'])) for r in csv.DictReader(h)}
    families=sorted(set(raw['family_parent'])|set(native));genes=raw['genes']
    acs,refs,query_counts=acs_gene_table(matrix_dir,project,genes,families)
    weights=np.zeros_like(acs);eligible=np.zeros_like(acs,dtype=bool)
    informative=np.zeros_like(eligible);votes=np.zeros_like(eligible)
    for j,family in enumerate(families):
        for i,gene in enumerate(genes):
            exons=raw['exon_values'].get(family,{}).get(gene,[])
            eligible[i,j]=bool(exons)
            weights[i,j]=sum(x if x>=.1 else 0 for x in exons)/len(exons) if exons else 0
            informative[i,j]=any(x>=.1 for x in exons)
            votes[i,j]=gene in raw['raw_gene_votes'].get(family,[])
    scores=acs.sum(axis=0);sd=scores.std();zs=(scores-scores.mean())/sd if sd else np.zeros_like(scores)
    for i,f in enumerate(families):
        assert f in native,f
        if not np.isclose(scores[i],native[f]['score'],rtol=1e-9,atol=1e-9):
            raise ValueError('Original ACS reconstruction mismatch: '+f)
        if not np.isclose(zs[i],native[f]['z'],rtol=1e-9,atol=1e-9):
            raise ValueError('Original Z reconstruction mismatch: '+f)
    assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in before.items())
    return dict(schema=1,project=project,genes=genes,families=families,
        acs=acs.tolist(),weights=weights.tolist(),eligible=eligible.tolist(),
        informative=informative.tolist(),votes=votes.tolist(),family_parent=raw['family_parent'],
        reference_species=refs,query_columns_per_exon=query_counts,
        missing_sibling_genes={f:len(raw['ambiguous_genes'].get(f,[])) for f in families},
        input_sha256=before,acs_reconstruction_verified=True,truth_used=False,
        extraction_scope='Original no-threshold/no-flag stage03 masking plus frozen gene-rescue features; no tree edits')

"""Repeated-gene confirmation for the frozen Z-plus-rescue family strategy."""
from __future__ import annotations

import csv
from pathlib import Path

from .adaptive import extract_family_features, read_predictions
from .hybrid import z_rescue_family_selection


def confirmation_state(*, rescue_selected: bool, raw_gene_votes: int | None,
                       comparable_genes: int | None) -> str:
    if rescue_selected:
        return 'retain_rescue'
    if raw_gene_votes is None or comparable_genes is None or comparable_genes < 2:
        return 'retain_insufficient_coverage_to_judge'
    if raw_gene_votes < 2:
        return 'unconfirmed_no_repeated_gene_support'
    return 'retain_repeated_gene_support'


def confirmed_family_selection(features: dict, predictions: dict, *, z_threshold: float) -> dict:
    result = z_rescue_family_selection(features, predictions, z_threshold=z_threshold)
    for row in result['rows']:
        row['hybrid_selected'] = row['selected']
        if row['hybrid_selected']:
            state = confirmation_state(rescue_selected=row['rescue_selected'],
                raw_gene_votes=row['raw_gene_votes'], comparable_genes=row['comparable_genes'])
            row['selected'] = not state.startswith('unconfirmed')
            row['confirmation_status'] = state
        else:
            row['confirmation_status'] = 'not_in_hybrid_candidates'
    result['prefilter_selected'] = result['selected']
    result['selected'] = [r['taxon'] for r in result['rows'] if r['selected']]
    result['unconfirmed'] = [r['taxon'] for r in result['rows']
                            if r['confirmation_status'].startswith('unconfirmed')]
    result['scope'] = 'Original strict Z threshold OR independent gene rescue, then repeated-gene confirmation for Z-only candidates'
    return result


def select_confirmed_family_candidates(matrix_dir: Path, predictions_csv: Path,
        output_path: Path, report_path: Path, *, project: str, z_threshold: float,
        unconfirmed_output: Path | None = None, prefilter_output: Path | None = None) -> dict:
    result = confirmed_family_selection(extract_family_features(matrix_dir, project),
        read_predictions(predictions_csv), z_threshold=z_threshold)
    for path, values in [(output_path, result['selected']),
                         (unconfirmed_output, result['unconfirmed']),
                         (prefilter_output, result['prefilter_selected'])]:
        if path is not None:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(''.join(f'{name}\n' for name in values), encoding='utf-8')
    report_path.parent.mkdir(parents=True, exist_ok=True)
    with report_path.open('w', newline='', encoding='utf-8') as handle:
        writer = csv.DictWriter(handle, fieldnames=list(result['rows'][0]))
        writer.writeheader(); writer.writerows(result['rows'])
    return result

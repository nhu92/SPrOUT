"""Original SPrOUT Z admission plus a separate gene-distance rescue channel."""
from __future__ import annotations

import csv
import math
from pathlib import Path

from .adaptive import adaptive_family_selection, extract_family_features, read_predictions


def z_rescue_family_selection(features: dict, predictions: dict, *, z_threshold: float) -> dict:
    if not math.isfinite(z_threshold):
        raise ValueError('Z threshold must be finite')
    # Reuse the previously studied gene/distance stability preset. Rescue is
    # independent of aggregate Z and is not truncated to a fixed family count.
    rescue = adaptive_family_selection(features, {}, z_flexibility=0., max_candidates=None)
    rescue_rows = {r['taxon']: r for r in rescue['rows']}
    rows = []
    for family in sorted(set(predictions) | set(rescue_rows)):
        value = predictions.get(family, {}).get('z_score')
        z = float(value) if value is not None else None
        native = z is not None and math.isfinite(z) and z > z_threshold
        evidence = rescue_rows.get(family, {})
        recovered = evidence.get('selected', False)
        route = 'z_and_rescue' if native and recovered else 'z_only' if native else 'rescue_only' if recovered else 'not_selected'
        rows.append(dict(taxon=family, parent_order=features['family_parent'].get(family, ''),
            selected=native or recovered, admission_route=route, original_z=z,
            z_threshold=z_threshold, native_z_selected=native, rescue_selected=recovered,
            rescue_status=evidence.get('selection_status', 'no_distance_features'),
            **{key: evidence.get(key) for key in ['raw_gene_votes','discriminating_genes','comparable_genes',
                'missing_sibling_genes','effective_gene_score','bootstrap_lower','adaptive_threshold']}))
    rows.sort(key=lambda r: (-int(r['selected']), -(r['original_z'] if r['original_z'] is not None and math.isfinite(r['original_z']) else -math.inf), r['taxon']))
    return dict(selected=[r['taxon'] for r in rows if r['selected']], rows=rows,
        z_threshold=z_threshold, rescue_parameters=rescue['parameters'],
        project=features['project'], scope='Fixed trees; original strict Z > threshold OR Z-independent distance/gene rescue')


def select_z_rescue_family_candidates(matrix_dir: Path, predictions_csv: Path,
        output_path: Path, report_path: Path, *, project: str, z_threshold: float) -> dict:
    result = z_rescue_family_selection(extract_family_features(matrix_dir, project),
        read_predictions(predictions_csv), z_threshold=z_threshold)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(''.join(f'{name}\n' for name in result['selected']), encoding='utf-8')
    with report_path.open('w', newline='', encoding='utf-8') as handle:
        writer = csv.DictWriter(handle, fieldnames=list(result['rows'][0]))
        writer.writeheader(); writer.writerows(result['rows'])
    return result

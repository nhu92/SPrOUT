"""Bounded distance evidence and gene-resampled adaptive Z admission.

No sample composition, true labels or expected member count are accepted.
"""
from __future__ import annotations

import csv
import math
import re
from collections import defaultdict
from pathlib import Path

from .candidates import taxon_from_sprout_header

DEFAULTS = {
    "minimum_gene_votes": 3,
    "minimum_comparable_genes": 10,
    "minimum_margin": 0.10,
    "base_lower_support": 0.02,
    "z_flexibility": 0.25,
    "z_scale": 3.0,
    "bootstrap_quantile": 0.10,
    "bootstrap_replicates": 1000,
    "seed": 20261015,
    "max_candidates": None,
}


def extract_family_features(matrix_dir: Path, project: str) -> dict:
    """Summarize raw query distances, giving each gene a bounded budget."""
    matrices = sorted(Path(matrix_dir).glob("*.cleaned.csv"))
    if not matrices:
        raise FileNotFoundError(f"No matrices in {matrix_dir}")
    parsed = []
    family_parent = {}
    parent_families = defaultdict(set)
    queries_seen = 0
    for path in matrices:
        with path.open(encoding="utf-8-sig", newline="") as handle:
            reader = csv.reader(handle)
            header = next(reader)
            query_indices = [i for i, name in enumerate(header) if i and project in name]
            refs = []
            for row in reader:
                label = row[0].strip().strip("'").removeprefix("_R_")
                if project in label or "NODE" in label or not label:
                    continue
                parts = label.split("_")
                if len(parts) < 4:
                    raise ValueError(f"Invalid reference taxonomy {label!r}")
                parent, family = parts[:2]
                if family in family_parent and family_parent[family] != parent:
                    raise ValueError(f"Conflicting parent orders for {family}")
                family_parent[family] = parent
                parent_families[parent].add(family)
                distances = [float(row[i]) for i in query_indices]
                if any(not math.isfinite(d) or d < 0 or d >= 999 for d in distances):
                    raise ValueError(f"Unfiltered finite nonnegative distances required: {path}")
                refs.append((parent, family, distances))
        if not refs or not query_indices:
            continue
        queries_seen += len(query_indices)
        gene = re.sub(r"\.\d+$", "", path.name.removesuffix(".cleaned.csv"))
        parsed.append((path.name, gene, query_indices, refs))
    if not parsed:
        raise ValueError(f"No reference/query evidence for {project!r}")
    genes = sorted({item[1] for item in parsed})
    # Per-gene lists are exon scores. Missing reference exons are not interpreted
    # as negative sample evidence, but require adequate comparable coverage.
    values = defaultdict(lambda: defaultdict(list))
    margins = defaultdict(lambda: defaultdict(list))
    raw_votes = defaultdict(set)
    ambiguous = defaultdict(set)
    events = []
    for name, gene, query_indices, refs in parsed:
        present = defaultdict(set)
        for parent, family, _ in refs:
            present[parent].add(family)
        comparable = {family for parent, families in present.items() for family in families
                      if len(families) >= 2 or len(parent_families[parent]) == 1}
        exon_best = defaultdict(float)
        exon_margins = defaultdict(list)
        for q in range(len(query_indices)):
            by_family = {}
            for _, family, distances in refs:
                by_family[family] = min(by_family.get(family, math.inf), distances[q])
            best = min(by_family.values())
            winners = [f for f, d in by_family.items()
                       if math.isclose(d, best, rel_tol=1e-9, abs_tol=1e-12)]
            for family in winners:
                raw_votes[family].add(gene)
            # A cross-family tie supplies no discriminating family evidence.
            if len(winners) != 1:
                continue
            family = winners[0]
            parent = family_parent[family]
            competitors = [d for f, d in by_family.items()
                           if f != family and family_parent[f] == parent]
            if not competitors and len(parent_families[parent]) == 1:
                competitors = [d for f, d in by_family.items() if f != family]
            if not competitors:
                ambiguous[family].add(gene)
                events.append({"matrix": name, "gene": gene, "family": family,
                               "status": "missing_sibling_reference", "margin": 0.0})
                continue
            runner = min(competitors)
            margin = max(0.0, min(1.0, (runner - best) / runner)) if runner > 0 else 0.0
            exon_best[family] = max(exon_best[family], margin)
            exon_margins[family].append(margin)
            events.append({"matrix": name, "gene": gene, "family": family,
                           "status": "comparable", "margin": margin,
                           "best_distance": best, "runner_distance": runner})
        for family in comparable:
            values[family][gene].append(exon_best[family])
            margins[family][gene].extend(exon_margins[family])
    return {"project": project, "matrices": len(parsed), "query_columns": queries_seen,
            "genes": genes, "family_parent": family_parent,
            "exon_values": {f: dict(by_gene) for f, by_gene in values.items()},
            "winning_margins": {f: dict(by_gene) for f, by_gene in margins.items()},
            "raw_gene_votes": {f: sorted(v) for f, v in raw_votes.items()},
            "ambiguous_genes": {f: sorted(v) for f, v in ambiguous.items()},
            "events": events}


def adaptive_family_selection(features: dict, predictions: dict, **options) -> dict:
    """Z adjusts a stability threshold by at most 25%; it cannot override gates.

    Gene bootstrap lower bounds are stability diagnostics, not calibrated
    probabilities, p-values, or false-discovery-rate guarantees.
    """
    import numpy as np

    params = {**DEFAULTS, **options}
    if set(options) - set(DEFAULTS):
        raise ValueError(f"Unknown options: {set(options) - set(DEFAULTS)}")
    for key in ["minimum_gene_votes", "minimum_comparable_genes", "bootstrap_replicates"]:
        if not isinstance(params[key], int) or params[key] < 1:
            raise ValueError(f"{key} must be a positive integer")
    if params['max_candidates'] is not None and (not isinstance(params['max_candidates'], int) or params['max_candidates'] < 1):
        raise ValueError('max_candidates must be a positive integer or None for unlimited')
    if not (0 <= params['minimum_margin'] <= 1 and 0 < params['base_lower_support'] <= 1
            and 0 <= params['z_flexibility'] < 1 and params['z_scale'] > 0
            and 0 < params['bootstrap_quantile'] < .5):
        raise ValueError("Invalid adaptive evidence parameters")
    genes = features['genes']
    if not genes:
        raise ValueError('No usable genes')
    rng = np.random.default_rng(params['seed'])
    resamples = rng.integers(0, len(genes), size=(params['bootstrap_replicates'], len(genes)))
    rows = []
    taxa = set(features['family_parent']) | set(predictions)
    for family in sorted(taxa):
        per_gene = features['exon_values'].get(family, {})
        weights = []
        eligible = []
        informative = 0
        for gene in genes:
            exons = per_gene.get(gene, [])
            if any(not math.isfinite(x) or not 0 <= x <= 1 for x in exons):
                raise ValueError('Gene evidence must be finite and bounded in [0, 1]')
            filtered = [x if x >= params['minimum_margin'] else 0.0 for x in exons]
            weights.append(sum(filtered) / len(filtered) if filtered else 0.0)
            eligible.append(bool(exons))
            informative += any(x >= params['minimum_margin'] for x in exons)
        weights = np.asarray(weights)
        eligible = np.asarray(eligible, dtype=float)
        n = int(eligible.sum())
        sampled_n = eligible[resamples].sum(axis=1)
        sampled_score = weights[resamples].sum(axis=1)
        sampled_mean = np.divide(sampled_score, sampled_n, out=np.zeros_like(sampled_score), where=sampled_n > 0)
        lower = float(np.quantile(sampled_mean, params['bootstrap_quantile']))
        mean = float(weights.sum() / n) if n else 0.0
        prediction = predictions.get(family, {})
        z = prediction.get('z_score', 0.0)
        z = float(z) if z is not None and math.isfinite(float(z)) else 0.0
        z_effect = math.tanh(z / params['z_scale'])
        threshold = params['base_lower_support'] * (1 - params['z_flexibility'] * z_effect)
        if n < params['minimum_comparable_genes']:
            status = 'low_comparative_coverage'
        elif informative < params['minimum_gene_votes']:
            status = 'too_few_discriminating_genes'
        elif lower < threshold:
            status = 'unstable_or_weak_distance_evidence'
        else:
            status = 'eligible'
        rows.append({'taxon': family, 'parent_order': features['family_parent'].get(family, ''),
            'selected': False, 'selection_status': status,
            'raw_gene_votes': len(features['raw_gene_votes'].get(family, [])),
            'discriminating_genes': int(informative), 'comparable_genes': n,
            'missing_sibling_genes': len(features['ambiguous_genes'].get(family, [])),
            'effective_gene_score': float(weights.sum()), 'mean_margin_evidence': mean,
            'bootstrap_lower': lower, 'adaptive_threshold': threshold, 'legacy_z': z,
            'bounded_z_effect': z_effect,
            'rank_score': lower * (1 + .15 * z_effect)})
    rows.sort(key=lambda r: (-r['rank_score'], -r['discriminating_genes'], r['taxon']))
    selected = []
    for row in rows:
        if row['selection_status'] == 'eligible':
            if params['max_candidates'] is None or len(selected) < params['max_candidates']:
                row['selected'] = True
                row['selection_status'] = 'selected'
                selected.append(row['taxon'])
            else:
                row['selection_status'] = 'capacity_excluded'
    primary_orders = set()
    for row in rows:
        row['association_tier'] = 'unconfirmed'
        if row['selected']:
            row['association_tier'] = ('primary_in_order' if row['parent_order'] not in primary_orders
                                       else 'additional_in_order')
            primary_orders.add(row['parent_order'])
    return {'selected': selected, 'rows': rows, 'parameters': params,
            'independent_genes': len(genes), 'project': features['project']}


def read_predictions(path: Path) -> dict:
    with Path(path).open(encoding='utf-8-sig', newline='') as handle:
        return {row['row_name']: {'z_score': float(row['z_score']) if row.get('z_score') else 0.0}
                for row in csv.DictReader(handle)}


def select_adaptive_family_candidates(matrix_dir: Path, predictions_csv: Path,
                                      output_path: Path, report_path: Path,
                                      *, project: str, **options) -> dict:
    result = adaptive_family_selection(extract_family_features(matrix_dir, project),
                                       read_predictions(predictions_csv), **options)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(''.join(f'{name}\n' for name in result['selected']), encoding='utf-8')
    with report_path.open('w', encoding='utf-8', newline='') as handle:
        writer = csv.DictWriter(handle, fieldnames=list(result['rows'][0]))
        writer.writeheader()
        writer.writerows(result['rows'])
    return result

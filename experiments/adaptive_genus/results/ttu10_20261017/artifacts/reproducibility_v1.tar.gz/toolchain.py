import hashlib,json,subprocess,shutil,os
from pathlib import Path
from datetime import datetime,timezone
os.environ['PATH']='/home/nhu/miniconda3/envs/sprout/bin:'+os.environ['PATH']
rows={}
for name,args in [('mafft',['--version']),('trimal',['--version']),('fasttree',[])]:
 p=Path(shutil.which(name));r=subprocess.run([str(p),*args],input='',capture_output=True,text=True,timeout=10)
 rows[name]={'path':str(p),'resolved':str(p.resolve()),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'mtime_utc':datetime.fromtimestamp(p.stat().st_mtime,timezone.utc).isoformat(),'version_output':'\n'.join((r.stdout+r.stderr).splitlines()[:8]),'returncode':r.returncode}
result={'recorded_utc':datetime.now(timezone.utc).isoformat(),'timing':'Observed during frozen runs; CLI binaries were not separately hashed in PROTOCOL at launch','executables':rows}
Path(__file__).with_name('TOOLCHAIN.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))

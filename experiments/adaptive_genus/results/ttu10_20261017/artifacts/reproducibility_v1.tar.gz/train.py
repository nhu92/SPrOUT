import os
from pathlib import Path
import sys
import hashlib
import json

root=Path(__file__).resolve().parent
os.environ['PATH']='/home/nhu/miniconda3/envs/sprout/bin:'+os.environ['PATH']
for name in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'):
    os.environ[name]='1'
sys.path.insert(0,str(root/'code'))
from experiments.adaptive_genus.model import train
panels=sorted(Path('/lustre/scratch/nhu/202609/ttu_100mixes10_progressive_full_20261014/samples').glob('*/03_genus/reference'))
genes=Path('/lustre/scratch/nhu/202609/ttu_nocap100_z09_20261015/samples/mix_07x26x30/00_query/gene_list.txt').read_text().split()
(root/'TRAIN_CODE_SHA.json').write_text(json.dumps({str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (root/'code').rglob('*.py')},indent=2)+'\n')
print(json.dumps(train(panels,genes,root/'model',workers=8),indent=2))

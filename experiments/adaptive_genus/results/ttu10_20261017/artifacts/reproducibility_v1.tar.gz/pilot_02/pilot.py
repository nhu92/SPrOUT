import os,sys,json,time
from pathlib import Path

root=Path(__file__).resolve().parent
os.environ['PATH']='/home/nhu/miniconda3/envs/sprout/bin:'+os.environ['PATH']
for name in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'):
    os.environ[name]='1'
sys.path[:0]=[str(root/'code'),str(root/'sources/MrKnowItAll/src'),str(root/'sources')]
from experiments.adaptive_genus.phylogeny import TreeIndex,Cell
from experiments.adaptive_genus.references import ReferenceBank,dump
from experiments.adaptive_genus.runner import CACHE,BACKBONE
from experiments.adaptive_genus.scoring import route
from experiments.adaptive_genus.trees import infer_exons
from sprout_refbuilder.kew import KewClient
sample=json.loads((root/'code/experiments/adaptive_genus/cohort.json').read_text())['selected'][0]
genes=(Path(sample['source_run'])/'00_query/gene_list.txt').read_text().split()
start=time.monotonic();index=TreeIndex(CACHE/'treeoflife.current.tree')
with KewClient(CACHE) as client:
    bank=ReferenceBank(index,client,BACKBONE,genes,sample['families'],root/'bank',workers=8)
    cells=[Cell(f,tuple(sorted(set(index.by_family[f])&set(bank.by_tip)))) for f in sample['families']]
    cells=[c for c in cells if c.tips]
    cells=index.partition(cells,32)
    print('PLANNED',len(cells),len({g for c in cells for g in index.genera(c)}),flush=True)
    selected,mapping,details=bank.anchors(cells)
    print('QC_SELECTED',len(selected),flush=True)
    ref,panel=bank.panel(selected,root/'reference')
    trees,info=infer_exons(ref,Path(sample['source_run'])/'00_query/exon',panel['genes'],root/'trees',workers=8)
    chosen,evidence,votes=route(trees,mapping,cells,index)
    dump(root/'PILOT.json',{'truth_used':False,'initial_genera':len({g for c in cells for g in index.genera(c)}),
                          'selected_region_genera':len({g for c in chosen for g in index.genera(c)}),
                          'references':len(selected),'valid_genes':info['valid_genes'],'trees':len(trees),
                          'routing_evidence':evidence,'representatives':details,'seconds':time.monotonic()-start})
    print('PILOT COMPLETE',flush=True)
